
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using server.Services.Interfaces;

namespace server.Controllers;

[ApiController]
[Route("api/admin/recovery")]
[Authorize(Roles = "Admin")]
public sealed class AdminRecoveryController : ControllerBase
{
    private readonly IRecoveryCatalogService _catalogService;
    private readonly IRecoveryRecordSearchService _searchService;
    private readonly IUserRecoveryService _userRecoveryService;
    private readonly ILogger<AdminRecoveryController> _logger;

    public AdminRecoveryController(
        IRecoveryCatalogService catalogService,
        IRecoveryRecordSearchService searchService,
        IUserRecoveryService userRecoveryService,
        ILogger<AdminRecoveryController> logger
    )
    {
        _catalogService = catalogService;
        _searchService = searchService;
        _userRecoveryService = userRecoveryService;
        _logger = logger;
    }

    // GET: /api/admin/recovery/modules
    [HttpGet("modules")]
    public async Task<IActionResult> GetModules(
        CancellationToken cancellationToken
    )
    {
        try
        {
            var modules = await _catalogService.GetModulesAsync(
                cancellationToken
            );

            return Ok(new
            {
                success = true,
                message = "Recovery modules loaded successfully.",
                data = modules
            });
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            return StatusCode(499);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to load recovery modules.");

            return Problem(
                statusCode: StatusCodes.Status500InternalServerError,
                title: "Unable to load recovery modules."
            );
        }
    }

    // GET: /api/admin/recovery/records?module=identity&entity=User
    [HttpGet("records")]
    public async Task<IActionResult> SearchRecords(
        [FromQuery] string module,
        [FromQuery] string entity,
        [FromQuery] string? search,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken cancellationToken = default
    )
    {
        try
        {
            var result = await _searchService.SearchAsync(
                module,
                entity,
                search,
                page,
                pageSize,
                cancellationToken
            );

            return Ok(new
            {
                success = true,
                message = "Recovery records loaded successfully.",
                data = result
            });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new
            {
                success = false,
                message = ex.Message
            });
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            return StatusCode(499);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to search recovery records.");

            return Problem(
                statusCode: StatusCodes.Status500InternalServerError,
                title: "Unable to search recovery records."
            );
        }
    }

    // GET: /api/admin/recovery/users?search=...
    [HttpGet("users")]
    public async Task<IActionResult> SearchUsers(
        [FromQuery] string? search,
        CancellationToken cancellationToken
    )
    {
        try
        {
            var users = await _userRecoveryService.SearchAsync(
                search,
                cancellationToken
            );

            return Ok(new
            {
                success = true,
                message = "Recovery users loaded successfully.",
                data = users
            });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Recovery user search is unavailable.");

            return Problem(
                statusCode: StatusCodes.Status503ServiceUnavailable,
                title: "Recovery user search is unavailable."
            );
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            return StatusCode(499);
        }
    }

    // GET: /api/admin/recovery/users/{id}
    [HttpGet("users/{id:guid}")]
    public async Task<IActionResult> GetUser(
        Guid id,
        CancellationToken cancellationToken
    )
    {
        try
        {
            var user = await _userRecoveryService.GetByIdAsync(
                id,
                cancellationToken
            );

            if (user is null)
            {
                return NotFound(new
                {
                    success = false,
                    message = "User was not found in the recovery database."
                });
            }

            return Ok(new
            {
                success = true,
                data = user
            });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Unable to load recovery user {UserId}.", id);

            return Problem(
                statusCode: StatusCodes.Status503ServiceUnavailable,
                title: "Recovery user details are unavailable."
            );
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            return StatusCode(499);
        }
    }

    // POST: /api/admin/recovery/users/{id}/restore
    [HttpPost("users/{id:guid}/restore")]
    public async Task<IActionResult> RestoreUser(
        Guid id,
        CancellationToken cancellationToken
    )
    {
        try
        {
            var result = await _userRecoveryService.RestoreAsync(
                id,
                cancellationToken
            );

            return Ok(new
            {
                success = true,
                message = "User recovery completed.",
                data = result
            });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogWarning(
                ex,
                "User recovery validation failed for {UserId}.",
                id
            );

            return Conflict(new
            {
                success = false,
                message = ex.Message
            });
        }
        catch (Microsoft.EntityFrameworkCore.DbUpdateException ex)
        {
            _logger.LogWarning(
                ex,
                "Database conflict while recovering user {UserId}.",
                id
            );

            return Conflict(new
            {
                success = false,
                message = "The user could not be restored because of a database conflict."
            });
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            return StatusCode(499);
        }
    }
}
