using Microsoft.EntityFrameworkCore;
using server.Models.Assessment;
using server.Models.Attendance;
using server.Models.Auth;
using server.Models.Backup;
using server.Models.Learning;
using server.Models.Otp;
using server.Models.Participant;
using server.Models.Service;
using server.Models.Trainer;
using server.Models.Training;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using server.Interfaces;

namespace server.Data;

public class ApplicationDbContext : DbContext
{

    private readonly ICacheService _cacheService;
    public ApplicationDbContext(
    DbContextOptions<ApplicationDbContext> options,
    ICacheService cacheService)
    : base(options)
{
    _cacheService = cacheService;
}

// =========================================================
// AUTOMATIC CACHE INVALIDATION
// =========================================================

private bool HasPendingDatabaseChanges()
{
    return ChangeTracker
        .Entries()
        .Any(entry =>
            entry.State == EntityState.Added ||
            entry.State == EntityState.Modified ||
            entry.State == EntityState.Deleted);
}

// Synchronous save
public override int SaveChanges()
{
    var hasChanges = HasPendingDatabaseChanges();

    var result = base.SaveChanges();

    if (hasChanges)
    {
        _cacheService.Clear();
    }

    return result;
}

// Synchronous save with acceptAllChangesOnSuccess
public override int SaveChanges(
    bool acceptAllChangesOnSuccess)
{
    var hasChanges = HasPendingDatabaseChanges();

    var result = base.SaveChanges(
        acceptAllChangesOnSuccess);

    if (hasChanges)
    {
        _cacheService.Clear();
    }

    return result;
}

// Asynchronous save
public override async Task<int> SaveChangesAsync(
    CancellationToken cancellationToken = default)
{
    var hasChanges = HasPendingDatabaseChanges();

    var result = await base.SaveChangesAsync(
        cancellationToken);

    if (hasChanges)
    {
        _cacheService.Clear();
    }

    return result;
}

// Asynchronous save with acceptAllChangesOnSuccess
public override async Task<int> SaveChangesAsync(
    bool acceptAllChangesOnSuccess,
    CancellationToken cancellationToken = default)
{
    var hasChanges = HasPendingDatabaseChanges();

    var result = await base.SaveChangesAsync(
        acceptAllChangesOnSuccess,
        cancellationToken);

    if (hasChanges)
    {
        _cacheService.Clear();
    }

    return result;
}

    
public DbSet<TrainingProgramRequirement>
    TrainingProgramRequirements
    { get; set; } = default!;
    public DbSet<User> Users
        => Set<User>();

public DbSet<Backup> Backups
    => Set<Backup>();
    public DbSet<LearningMaterial> LearningMaterials
    => Set<LearningMaterial>();

    public DbSet<Service> Services
    => Set<Service>();

public DbSet<ServiceRequirement> ServiceRequirements
    => Set<ServiceRequirement>();

    

    public DbSet<AssessmentRetakeRequest> AssessmentRetakeRequests
    => Set<AssessmentRetakeRequest>();

public DbSet<ServiceRequest> ServiceRequests
    => Set<ServiceRequest>();
public DbSet<ServiceConsultation> ServiceConsultations { get; set; }

public DbSet<LearningSectionProgress>
    LearningSectionProgresses
    => Set<LearningSectionProgress>();
    public DbSet<LearningModule> LearningModules
    => Set<LearningModule>();

public DbSet<LearningSection> LearningSections
    => Set<LearningSection>();
    
    public DbSet<OtpVerification> OtpVerifications
        => Set<OtpVerification>();

    public DbSet<ParticipantProfile> ParticipantProfiles
        => Set<ParticipantProfile>();

   public DbSet<TrainerReportRequest> TrainerReportRequests
    => Set<TrainerReportRequest>();

public DbSet<TrainerApplication> TrainerApplications
    => Set<TrainerApplication>();

public DbSet<TrainerApplicationDocument> TrainerApplicationDocuments
    => Set<TrainerApplicationDocument>();

public DbSet<TrainerApplicationEducation> TrainerApplicationEducations
    => Set<TrainerApplicationEducation>();

public DbSet<TrainerApplicationCertification> TrainerApplicationCertifications
    => Set<TrainerApplicationCertification>();

public DbSet<TrainerProfile> TrainerProfiles
    => Set<TrainerProfile>();

public DbSet<TrainerEducation> TrainerEducations
    => Set<TrainerEducation>();

public DbSet<TrainerCertification> TrainerCertifications
    => Set<TrainerCertification>();

    

    public DbSet<TrainingProgram> TrainingPrograms
        => Set<TrainingProgram>();

    public DbSet<TrainingProgramDocument> TrainingProgramDocuments
        => Set<TrainingProgramDocument>();

    public DbSet<TrainingBatch> TrainingBatches
        => Set<TrainingBatch>();

        public DbSet<TrainingSession> TrainingSessions
    => Set<TrainingSession>();

    public DbSet<TrainerAssignment> TrainerAssignments
        => Set<TrainerAssignment>();

    // ==========================================
    // Enrollment
    // ==========================================

    public DbSet<Enrollment> Enrollments
        => Set<Enrollment>();

    public DbSet<EnrollmentDocument> EnrollmentDocuments
        => Set<EnrollmentDocument>();

public DbSet<WrittenAssessment> WrittenAssessments => Set<WrittenAssessment>();

public DbSet<AssessmentQuestion> AssessmentQuestions => Set<AssessmentQuestion>();

public DbSet<AssessmentChoice> AssessmentChoices => Set<AssessmentChoice>();

public DbSet<AssessmentAttempt> AssessmentAttempts => Set<AssessmentAttempt>();

public DbSet<AssessmentAnswer> AssessmentAnswers => Set<AssessmentAnswer>();

public DbSet<AssessmentResult> AssessmentResults => Set<AssessmentResult>();

public DbSet<AttendanceSession> AttendanceSessions => Set<AttendanceSession>();

public DbSet<AttendanceRecord> AttendanceRecords => Set<AttendanceRecord>();

public DbSet<PracticalAssessment>
    PracticalAssessments
    => Set<PracticalAssessment>();

public DbSet<PracticalAssessmentCriterion>
    PracticalAssessmentCriteria
    => Set<PracticalAssessmentCriterion>();

public DbSet<PracticalAssessmentResult>
    PracticalAssessmentResults
    => Set<PracticalAssessmentResult>();

public DbSet<PracticalAssessmentCriterionScore>
    PracticalAssessmentCriterionScores
    => Set<PracticalAssessmentCriterionScore>();
public DbSet<ParticipationSetting>
    ParticipationSettings
    => Set<ParticipationSetting>();

public DbSet<ParticipationRecord>
    ParticipationRecords
    => Set<ParticipationRecord>();

    public DbSet<Certificate> Certificates => Set<Certificate>();

    public DbSet<LearningModuleChunk> LearningModuleChunks
    => Set<LearningModuleChunk>();

    public DbSet<LearningModuleFile> LearningModuleFiles
    => Set<LearningModuleFile>();

    
    // ==========================================
    // Model Configuration
    // ==========================================

    protected override void OnModelCreating(
        ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);


        // ==========================================
        // USER
        // ==========================================

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(x => x.Id);

            entity.Property(x => x.UserCode)
                .IsRequired()
                .HasMaxLength(50);

            entity.HasIndex(x => x.UserCode)
                .IsUnique();

            entity.Property(x => x.FullName)
                .IsRequired()
                .HasMaxLength(150);

            entity.Property(x => x.Email)
                .IsRequired()
                .HasMaxLength(255);

            entity.HasIndex(x => x.Email)
                .IsUnique();

            entity.Property(x => x.MobileNumber)
                .HasMaxLength(30);

            entity.Property(x => x.PasswordHash)
                .IsRequired();

            entity.Property(x => x.Role)
                .HasConversion<string>()
                .IsRequired();

            entity.Property(x => x.Status)
                .HasConversion<string>()
                .IsRequired();

            entity.Property(x => x.IsEmailVerified)
                .IsRequired();

            entity.Property(x => x.CreatedAt)
                .IsRequired();

            entity.Property(x => x.UpdatedAt)
                .IsRequired();


            // User 1 : 1 ParticipantProfile

            entity.HasOne(x => x.ParticipantProfile)
                .WithOne(x => x.User)
                .HasForeignKey<ParticipantProfile>(
                    x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });


// ==========================================
// BACKUP
// ==========================================

modelBuilder.Entity<Backup>(entity =>
{
    entity.ToTable("Backups");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.FileName)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.FilePath)
        .HasMaxLength(1000);

    entity.Property(x => x.FileSize)
        .IsRequired();

    entity.Property(x => x.BackupType)
        .IsRequired()
        .HasMaxLength(50);

    entity.Property(x => x.Status)
        .IsRequired()
        .HasMaxLength(50);

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.CompletedAt)
        .IsRequired(false);

    entity.Property(x => x.CreatedByUserId)
        .IsRequired(false);

    entity.Property(x => x.ErrorMessage)
        .HasMaxLength(2000);

    entity.HasIndex(x => x.CreatedAt);

    entity.HasIndex(x => x.Status);

    entity.HasIndex(x => x.BackupType);
});
       
        modelBuilder.Entity<Certificate>(entity =>
{
    entity.ToTable("Certificates");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.CertificateNumber)
        .IsRequired()
        .HasMaxLength(50);

    entity.Property(x => x.Type)
        .IsRequired();

    entity.Property(x => x.IssuedAt)
        .IsRequired();

    entity.Property(x => x.VerificationCode)
        .IsRequired()
        .HasMaxLength(100);

    entity.Property(x => x.PdfUrl)
        .HasMaxLength(500);

   

    entity.Property(x => x.IsRevoked)
        .IsRequired();

    entity.Property(x => x.RevocationReason)
        .HasMaxLength(500);

    entity.HasIndex(x => x.CertificateNumber)
        .IsUnique();

    entity.HasIndex(x => x.VerificationCode)
        .IsUnique();

    // One participation certificate per enrollment
    // and one completion certificate per enrollment.
    entity.HasIndex(x => new
    {
        x.EnrollmentId,
        x.Type
    })
    .IsUnique();

    entity.HasOne(x => x.Enrollment)
        .WithMany()
        .HasForeignKey(x => x.EnrollmentId)
        .OnDelete(DeleteBehavior.Cascade);
});
// ==========================================================
// PARTICIPATION SETTING
// ==========================================================

modelBuilder.Entity<ParticipationSetting>(entity =>
{
    entity.ToTable("ParticipationSettings");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.RequiredRecitations)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired(false);

    // One participation setting per training batch
    entity.HasIndex(x => x.TrainingBatchId)
        .IsUnique();

    entity.HasOne(x => x.TrainingBatch)
        .WithMany()
        .HasForeignKey(x => x.TrainingBatchId)
        .OnDelete(DeleteBehavior.Cascade);
});


// ==========================================================
// PARTICIPATION RECORD
// ==========================================================

modelBuilder.Entity<ParticipationRecord>(entity =>
{
    entity.ToTable("ParticipationRecords");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.RecordedByUserId)
        .IsRequired();

    entity.Property(x => x.RecordedAt)
        .IsRequired();

    entity.Property(x => x.Remarks)
        .HasMaxLength(500);

    // One recitation record per participant per session
    entity.HasIndex(x => new
    {
        x.EnrollmentId,
        x.TrainingSessionId
    })
    .IsUnique();

    entity.HasIndex(x => x.EnrollmentId);

    entity.HasIndex(x => x.TrainingSessionId);

    entity.HasOne(x => x.Enrollment)
        .WithMany()
        .HasForeignKey(x => x.EnrollmentId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(x => x.TrainingSession)
        .WithMany()
        .HasForeignKey(x => x.TrainingSessionId)
        .OnDelete(DeleteBehavior.Cascade);
});

        // ==========================================================
// PRACTICAL ASSESSMENT
// ==========================================================

modelBuilder.Entity<PracticalAssessment>(entity =>
{
    entity.ToTable("PracticalAssessments");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Title)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.Description)
        .HasMaxLength(2000);

    entity.Property(x => x.PassingPercentage)
        .HasPrecision(5, 2)
        .IsRequired();

    entity.Property(x => x.IsPublished)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired(false);

    entity.HasIndex(x => x.TrainingBatchId);

    entity.HasOne(x => x.TrainingBatch)
        .WithMany()
        .HasForeignKey(x => x.TrainingBatchId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasMany(x => x.Criteria)
        .WithOne(x => x.PracticalAssessment)
        .HasForeignKey(x => x.PracticalAssessmentId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasMany(x => x.Results)
        .WithOne(x => x.PracticalAssessment)
        .HasForeignKey(x => x.PracticalAssessmentId)
        .OnDelete(DeleteBehavior.Cascade);
});

// ==========================================================
// PRACTICAL ASSESSMENT CRITERION
// ==========================================================

modelBuilder.Entity<PracticalAssessmentCriterion>(entity =>
{
    entity.ToTable("PracticalAssessmentCriteria");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Name)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.Description)
        .HasMaxLength(1000);

    entity.Property(x => x.WeightPercentage)
        .HasPrecision(5, 2)
        .IsRequired();

    entity.Property(x => x.DisplayOrder)
        .IsRequired();

    entity.HasIndex(x => new
    {
        x.PracticalAssessmentId,
        x.DisplayOrder
    });

    entity.HasOne(x => x.PracticalAssessment)
        .WithMany(x => x.Criteria)
        .HasForeignKey(x => x.PracticalAssessmentId)
        .OnDelete(DeleteBehavior.Cascade);
});

// ==========================================================
// PRACTICAL ASSESSMENT RESULT
// ==========================================================

modelBuilder.Entity<PracticalAssessmentResult>(entity =>
{
    entity.ToTable("PracticalAssessmentResults");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.TotalScore)
        .HasPrecision(8, 2)
        .IsRequired();

    entity.Property(x => x.Percentage)
        .HasPrecision(5, 2)
        .IsRequired();

    entity.Property(x => x.IsPassed)
        .IsRequired();

    entity.Property(x => x.TrainerRemarks)
        .HasMaxLength(2000);

    entity.Property(x => x.EvaluatedByUserId)
        .IsRequired();

    entity.Property(x => x.EvaluatedAt)
        .IsRequired();

    // One result per participant/enrollment
    // for a practical assessment.
    entity.HasIndex(x => new
    {
        x.PracticalAssessmentId,
        x.EnrollmentId
    })
    .IsUnique();

    entity.HasIndex(x => x.EnrollmentId);

    entity.HasOne(x => x.PracticalAssessment)
        .WithMany(x => x.Results)
        .HasForeignKey(x => x.PracticalAssessmentId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(x => x.Enrollment)
        .WithMany()
        .HasForeignKey(x => x.EnrollmentId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasMany(x => x.CriterionScores)
        .WithOne(x => x.PracticalAssessmentResult)
        .HasForeignKey(x => x.PracticalAssessmentResultId)
        .OnDelete(DeleteBehavior.Cascade);
});

// ==========================================================
// PRACTICAL ASSESSMENT CRITERION SCORE
// ==========================================================

modelBuilder.Entity<PracticalAssessmentCriterionScore>(entity =>
{
    entity.ToTable("PracticalAssessmentCriterionScores");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Score)
        .HasPrecision(8, 2)
        .IsRequired();

    entity.HasIndex(x => new
    {
        x.PracticalAssessmentResultId,
        x.PracticalAssessmentCriterionId
    })
    .IsUnique();

    entity.HasOne(x => x.PracticalAssessmentResult)
        .WithMany(x => x.CriterionScores)
        .HasForeignKey(x => x.PracticalAssessmentResultId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(x => x.PracticalAssessmentCriterion)
        .WithMany(x => x.Scores)
        .HasForeignKey(x => x.PracticalAssessmentCriterionId)
        .OnDelete(DeleteBehavior.Restrict);
});



        modelBuilder.Entity<TrainingProgramRequirement>(
    entity =>
    {
        entity.HasKey(x => x.Id);

        entity.Property(x => x.Name)
            .IsRequired()
            .HasMaxLength(200);

        entity.Property(x => x.Description)
            .HasMaxLength(1000);

        entity.Property(x => x.IsRequired)
            .IsRequired();

        entity.Property(x => x.DisplayOrder)
            .IsRequired();

        entity.HasOne(x => x.TrainingProgram)
            .WithMany(x => x.Requirements)
            .HasForeignKey(x => x.TrainingProgramId)
            .OnDelete(DeleteBehavior.Cascade);

        entity.HasIndex(x => x.TrainingProgramId);
    }
);// ==========================================
// TRAINER APPLICATION
// ==========================================

modelBuilder.Entity<TrainerApplication>(entity =>
{
    entity.ToTable("TrainerApplications");

    entity.HasKey(x => x.Id);

    // One application per user
    entity.HasIndex(x => x.UserId)
        .IsUnique();

    // ==========================================
    // PERSONAL INFORMATION
    // ==========================================

    entity.Property(x => x.FirstName)
        .HasMaxLength(100);

    entity.Property(x => x.MiddleName)
        .HasMaxLength(100);

    entity.Property(x => x.LastName)
        .HasMaxLength(100);

    entity.Property(x => x.Suffix)
        .HasMaxLength(30);

    entity.Property(x => x.Gender)
        .HasMaxLength(50);

    entity.Property(x => x.Address)
        .HasMaxLength(500);

    // ==========================================
    // PROFESSIONAL INFORMATION
    // ==========================================

    entity.Property(x => x.Specialization)
        .IsRequired()
        .HasMaxLength(150);

    entity.Property(x => x.ProfessionalTitle)
        .HasMaxLength(150);

    entity.Property(x => x.CurrentOrganization)
        .HasMaxLength(200);

    entity.Property(x => x.Bio)
        .HasMaxLength(2000);

    entity.Property(x => x.YearsOfExperience)
        .IsRequired(false);

    // ==========================================
    // PROFESSIONAL LICENSE
    // ==========================================

    entity.Property(x => x.ProfessionalLicenseNumber)
        .HasMaxLength(150);

    entity.Property(x => x.ProfessionalLicenseType)
        .HasMaxLength(150);

    entity.Property(x => x.ProfessionalLicenseExpirationDate)
        .IsRequired(false);

    // ==========================================
    // PROFILE IMAGE
    // ==========================================

    entity.Property(x => x.ProfileImageUrl)
        .HasMaxLength(1000);

    // ==========================================
    // STATUS
    // ==========================================

    entity.Property(x => x.Status)
        .HasConversion<string>()
        .IsRequired();

    entity.Property(x => x.AdminRemarks)
        .HasMaxLength(1000);

    // ==========================================
    // USER RELATIONSHIP
    // ==========================================

    entity.HasOne(x => x.User)
        .WithOne(x => x.TrainerApplication)
        .HasForeignKey<TrainerApplication>(
            x => x.UserId)
        .OnDelete(DeleteBehavior.Cascade);

    // ==========================================
    // DOCUMENTS
    // ==========================================

    entity.HasMany(x => x.Documents)
        .WithOne(x => x.TrainerApplication)
        .HasForeignKey(x => x.TrainerApplicationId)
        .OnDelete(DeleteBehavior.Cascade);

    // ==========================================
    // EDUCATION
    // ==========================================

    entity.HasMany(x => x.Educations)
        .WithOne(x => x.TrainerApplication)
        .HasForeignKey(x => x.TrainerApplicationId)
        .OnDelete(DeleteBehavior.Cascade);

    // ==========================================
    // CERTIFICATIONS
    // ==========================================

    entity.HasMany(x => x.Certifications)
        .WithOne(x => x.TrainerApplication)
        .HasForeignKey(x => x.TrainerApplicationId)
        .OnDelete(DeleteBehavior.Cascade);
});
// ==========================================
// TRAINER APPLICATION EDUCATION
// ==========================================

modelBuilder.Entity<TrainerApplicationEducation>(entity =>
{
    entity.ToTable("TrainerApplicationEducations");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Degree)
        .IsRequired()
        .HasMaxLength(200);

    entity.Property(x => x.FieldOfStudy)
        .HasMaxLength(200);

    entity.Property(x => x.Institution)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.YearGraduated)
        .IsRequired(false);

    entity.HasIndex(x => x.TrainerApplicationId);

    entity.HasOne(x => x.TrainerApplication)
        .WithMany(x => x.Educations)
        .HasForeignKey(x => x.TrainerApplicationId)
        .OnDelete(DeleteBehavior.Cascade);
});

// ==========================================
// TRAINER APPLICATION CERTIFICATION
// ==========================================

modelBuilder.Entity<TrainerApplicationCertification>(entity =>
{
    entity.ToTable("TrainerApplicationCertifications");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Name)
        .IsRequired()
        .HasMaxLength(200);

    entity.Property(x => x.IssuingOrganization)
        .HasMaxLength(255);

    entity.Property(x => x.IssuedDate)
        .IsRequired(false);

    entity.Property(x => x.ExpirationDate)
        .IsRequired(false);

    entity.Property(x => x.CertificateUrl)
        .HasMaxLength(1000);

    entity.HasIndex(x => x.TrainerApplicationId);

    entity.HasOne(x => x.TrainerApplication)
        .WithMany(x => x.Certifications)
        .HasForeignKey(x => x.TrainerApplicationId)
        .OnDelete(DeleteBehavior.Cascade);
});
       // ==========================================
// TRAINER PROFILE
// ==========================================

modelBuilder.Entity<TrainerProfile>(entity =>
{
    entity.ToTable("TrainerProfiles");

    entity.HasKey(x => x.Id);

    entity.HasIndex(x => x.UserId)
        .IsUnique();

    // ==========================================
    // PERSONAL INFORMATION
    // ==========================================

    entity.Property(x => x.FirstName)
        .HasMaxLength(100);

    entity.Property(x => x.MiddleName)
        .HasMaxLength(100);

    entity.Property(x => x.LastName)
        .HasMaxLength(100);

    entity.Property(x => x.Suffix)
        .HasMaxLength(30);

    entity.Property(x => x.Gender)
        .HasMaxLength(50);

    entity.Property(x => x.Address)
        .HasMaxLength(500);

    // ==========================================
    // PROFESSIONAL INFORMATION
    // ==========================================

    entity.Property(x => x.Specialization)
        .IsRequired()
        .HasMaxLength(150);

    entity.Property(x => x.ProfessionalTitle)
        .HasMaxLength(150);

    entity.Property(x => x.CurrentOrganization)
        .HasMaxLength(200);

    entity.Property(x => x.Bio)
        .HasMaxLength(2000);

    entity.Property(x => x.YearsOfExperience)
        .IsRequired(false);

    // ==========================================
    // PROFESSIONAL LICENSE
    // ==========================================

    entity.Property(x => x.ProfessionalLicenseNumber)
        .HasMaxLength(150);

    entity.Property(x => x.ProfessionalLicenseType)
        .HasMaxLength(150);

    entity.Property(x => x.ProfessionalLicenseExpirationDate)
        .IsRequired(false);

    // ==========================================
    // PROFILE IMAGE
    // ==========================================

    entity.Property(x => x.ProfileImageUrl)
        .HasMaxLength(1000);

    // ==========================================
    // STATUS
    // ==========================================

    entity.Property(x => x.IsActive)
        .IsRequired();

    entity.Property(x => x.ActivatedAt)
        .IsRequired(false);

    // ==========================================
    // USER
    // ==========================================

    entity.HasOne(x => x.User)
        .WithOne(x => x.TrainerProfile)
        .HasForeignKey<TrainerProfile>(
            x => x.UserId)
        .OnDelete(DeleteBehavior.Cascade);

    // ==========================================
    // ASSIGNMENTS
    // ==========================================

    entity.HasMany(x => x.Assignments)
        .WithOne(x => x.TrainerProfile)
        .HasForeignKey(x => x.TrainerProfileId)
        .OnDelete(DeleteBehavior.Restrict);

    // ==========================================
    // EDUCATION
    // ==========================================

    entity.HasMany(x => x.Educations)
        .WithOne(x => x.TrainerProfile)
        .HasForeignKey(x => x.TrainerProfileId)
        .OnDelete(DeleteBehavior.Cascade);

    // ==========================================
    // CERTIFICATIONS
    // ==========================================

    entity.HasMany(x => x.Certifications)
        .WithOne(x => x.TrainerProfile)
        .HasForeignKey(x => x.TrainerProfileId)
        .OnDelete(DeleteBehavior.Cascade);
});

// ==========================================
// TRAINER CERTIFICATION
// ==========================================

modelBuilder.Entity<TrainerCertification>(entity =>
{
    entity.ToTable("TrainerCertifications");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Name)
        .IsRequired()
        .HasMaxLength(200);

    entity.Property(x => x.IssuingOrganization)
        .HasMaxLength(255);

    entity.Property(x => x.IssuedDate)
        .IsRequired(false);

    entity.Property(x => x.ExpirationDate)
        .IsRequired(false);

    entity.Property(x => x.CertificateUrl)
        .HasMaxLength(1000);

    entity.HasIndex(x => x.TrainerProfileId);

    entity.HasOne(x => x.TrainerProfile)
        .WithMany(x => x.Certifications)
        .HasForeignKey(x => x.TrainerProfileId)
        .OnDelete(DeleteBehavior.Cascade);
});

// ==========================================
// TRAINER EDUCATION
// ==========================================

modelBuilder.Entity<TrainerReportRequest>(
    entity =>
    {
        entity.HasKey(
            x => x.Id);

        entity.Property(
            x => x.ReportType)
            .IsRequired()
            .HasMaxLength(50);

        entity.Property(
            x => x.Reason)
            .HasMaxLength(1000);

        entity.Property(
            x => x.AdminRemarks)
            .HasMaxLength(1000);

        entity.Property(
            x => x.ReportFileUrl)
            .HasMaxLength(500);

        entity.HasOne(
            x => x.TrainerProfile)
            .WithMany(
                x => x.ReportRequests)
            .HasForeignKey(
                x => x.TrainerProfileId)
            .OnDelete(
                DeleteBehavior.Restrict);

        entity.HasOne(
            x => x.TrainingBatch)
            .WithMany(
                x => x.TrainerReportRequests)
            .HasForeignKey(
                x => x.TrainingBatchId)
            .OnDelete(
                DeleteBehavior.Restrict);

        entity.HasOne(
            x => x.ReviewedByUser)
            .WithMany()
            .HasForeignKey(
                x => x.ReviewedByUserId)
            .OnDelete(
                DeleteBehavior.SetNull);
    });

modelBuilder.Entity<TrainerEducation>(entity =>
{
    entity.ToTable("TrainerEducations");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Degree)
        .IsRequired()
        .HasMaxLength(200);

    entity.Property(x => x.FieldOfStudy)
        .HasMaxLength(200);

    entity.Property(x => x.Institution)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.YearGraduated)
        .IsRequired(false);

    entity.HasIndex(x => x.TrainerProfileId);

    entity.HasOne(x => x.TrainerProfile)
        .WithMany(x => x.Educations)
        .HasForeignKey(x => x.TrainerProfileId)
        .OnDelete(DeleteBehavior.Cascade);
});


        // ==========================================
        // TRAINER APPLICATION DOCUMENT
        // ==========================================

        modelBuilder.Entity<TrainerApplicationDocument>(entity =>
        {
            entity.HasKey(x => x.Id);

            entity.Property(x => x.DocumentType)
                .IsRequired()
                .HasMaxLength(100);

            entity.Property(x => x.FileName)
                .IsRequired()
                .HasMaxLength(255);

            entity.Property(x => x.FileUrl)
                .IsRequired()
                .HasMaxLength(1000);

            entity.Property(x => x.Status)
                .HasConversion<string>()
                .IsRequired();

            entity.Property(x => x.ReviewRemarks)
                .HasMaxLength(1000);

            entity.HasOne(x => x.TrainerApplication)
                .WithMany(x => x.Documents)
                .HasForeignKey(x => x.TrainerApplicationId)
                .OnDelete(DeleteBehavior.Cascade);
        });


        // ==========================================
        // PARTICIPANT PROFILE
        // ==========================================

        modelBuilder.Entity<ParticipantProfile>(entity =>
        {
            entity.HasKey(x => x.Id);

            entity.HasIndex(x => x.UserId)
                .IsUnique();

            entity.Property(x => x.FirstName)
                .HasMaxLength(100);

            entity.Property(x => x.MiddleName)
                .HasMaxLength(100);

            entity.Property(x => x.LastName)
                .HasMaxLength(100);

            entity.Property(x => x.Address)
                .HasMaxLength(500);

            entity.Property(x => x.Gender)
                .HasMaxLength(50);

            entity.Property(x => x.ProfileImageUrl)
                .HasMaxLength(500);
        });


        // ==========================================
        // OTP VERIFICATION
        // ==========================================

        modelBuilder.Entity<OtpVerification>(entity =>
        {
            entity.HasKey(x => x.Id);

            entity.Property(x => x.OtpCode)
                .IsRequired()
                .HasMaxLength(6);

            entity.Property(x => x.Purpose)
                .HasConversion<string>()
                .IsRequired();

            entity.Property(x => x.ExpiresAt)
                .IsRequired();

            entity.Property(x => x.IsUsed)
                .IsRequired();

            entity.Property(x => x.AttemptCount)
                .IsRequired();

            entity.Property(x => x.CreatedAt)
                .IsRequired();

            entity.HasOne(x => x.User)
                .WithMany(x => x.OtpVerifications)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });


        // ==========================================
        // TRAINING PROGRAM
        // ==========================================

        modelBuilder.Entity<TrainingProgram>(entity =>
        {
            entity.HasKey(x => x.Id);

            entity.Property(x => x.ProgramCode)
                .IsRequired()
                .HasMaxLength(50);

            entity.HasIndex(x => x.ProgramCode)
                .IsUnique();

            entity.Property(x => x.Name)
                .IsRequired()
                .HasMaxLength(200);

            entity.Property(x => x.Description)
                .HasMaxLength(1000);

            entity.Property(x => x.DurationHours)
                .IsRequired();

            entity.Property(x => x.IsActive)
                .IsRequired();

            entity.Property(x => x.CreatedAt)
                .IsRequired();


            // TrainingProgram 1 : many Batches

            entity.HasMany(x => x.Batches)
                .WithOne(x => x.TrainingProgram)
                .HasForeignKey(x => x.TrainingProgramId)
                .OnDelete(DeleteBehavior.Restrict);


            // TrainingProgram 1 : many Documents

            entity.HasMany(x => x.Documents)
                .WithOne(x => x.TrainingProgram)
                .HasForeignKey(x => x.TrainingProgramId)
                .OnDelete(DeleteBehavior.Cascade);
        });
        // ==========================================
// LEARNING MATERIAL
// ==========================================

modelBuilder.Entity<LearningMaterial>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.Title)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.Description)
        .HasMaxLength(2000);

    entity.Property(x => x.MaterialType)
        .IsRequired()
        .HasMaxLength(50);

    entity.Property(x => x.FileUrl)
        .IsRequired()
        .HasMaxLength(1000);

    entity.Property(x => x.PublicId)
        .HasMaxLength(500);

    entity.Property(x => x.FileName)
        .HasMaxLength(255);

    entity.Property(x => x.ContentType)
        .HasMaxLength(150);

    entity.Property(x => x.FileSize)
        .IsRequired(false);

    entity.Property(x => x.IsPublished)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired(false);

    entity.HasIndex(x => x.TrainingBatchId);
    entity.Property(x => x.ExtractedText)
    .HasColumnType("text");

    entity.HasIndex(x => new
    {
        x.TrainingBatchId,
        x.Title
    });

    entity.HasOne(x => x.TrainingBatch)
    .WithMany(x => x.LearningMaterials)
    .HasForeignKey(x => x.TrainingBatchId)
    .OnDelete(DeleteBehavior.Cascade);
});
// ==========================================
// LEARNING MODULE
// ==========================================

modelBuilder.Entity<LearningModule>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.Title)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.Description)
        .HasMaxLength(2000);

    entity.Property(x => x.WelcomeContent)
        .HasColumnType("text");

    entity.Property(x => x.LearningObjectives)
        .HasColumnType("text");

    entity.Property(x => x.Summary)
        .HasColumnType("text");

    entity.Property(x => x.KeyTakeaways)
        .HasColumnType("text");

    entity.Property(x => x.DisplayOrder)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired(false);

    entity.HasIndex(x => x.LearningMaterialId);

    // LearningMaterial 1 : many LearningModules
    entity.HasOne(x => x.LearningMaterial)
        .WithMany(x => x.Modules)
        .HasForeignKey(x => x.LearningMaterialId)
        .OnDelete(DeleteBehavior.Cascade);

    // LearningModule 1 : many LearningModuleFiles
    entity.HasMany(x => x.Files)
        .WithOne(x => x.LearningModule)
        .HasForeignKey(x => x.LearningModuleId)
        .OnDelete(DeleteBehavior.Cascade);

    // LearningModule 1 : many LearningModuleChunks
    entity.HasMany(x => x.Chunks)
        .WithOne(x => x.LearningModule)
        .HasForeignKey(x => x.LearningModuleId)
        .OnDelete(DeleteBehavior.Cascade);

    // LearningModule 1 : many LearningSections
    entity.HasMany(x => x.Sections)
        .WithOne(x => x.LearningModule)
        .HasForeignKey(x => x.LearningModuleId)
        .OnDelete(DeleteBehavior.Cascade);
});
// ==========================================
// LEARNING MODULE FILE
// ==========================================

modelBuilder.Entity<LearningModuleFile>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.FileUrl)
        .IsRequired()
        .HasMaxLength(1000);

    entity.Property(x => x.PublicId)
        .HasMaxLength(500);

    entity.Property(x => x.FileName)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.ContentType)
        .HasMaxLength(150);

    entity.Property(x => x.FileSize)
        .IsRequired();

    entity.Property(x => x.ExtractedText)
        .HasColumnType("text");

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired(false);

    entity.HasIndex(x => x.LearningModuleId);

    entity.HasOne(x => x.LearningModule)
        .WithMany(x => x.Files)
        .HasForeignKey(x => x.LearningModuleId)
        .OnDelete(DeleteBehavior.Cascade);

    // One file can have many chunks
    entity.HasMany(x => x.Chunks)
        .WithOne(x => x.LearningModuleFile)
        .HasForeignKey(x => x.LearningModuleFileId)
        .OnDelete(DeleteBehavior.Cascade);
});
// ==========================================
// LEARNING MODULE CHUNK
// ==========================================

modelBuilder.Entity<LearningModuleChunk>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.Content)
        .IsRequired()
        .HasColumnType("text");

    entity.Property(x => x.ChunkNumber)
        .IsRequired();

    entity.Property(x => x.CharacterCount)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    // Module + File + Chunk
    entity.HasIndex(x => new
    {
        x.LearningModuleFileId,
        x.ChunkNumber
    })
    .IsUnique();

    entity.HasIndex(x => x.LearningModuleId);

    entity.HasIndex(x => x.LearningModuleFileId);

    // LearningModule relationship
    entity.HasOne(x => x.LearningModule)
        .WithMany(x => x.Chunks)
        .HasForeignKey(x => x.LearningModuleId)
        .OnDelete(DeleteBehavior.Cascade);

    // LearningModuleFile relationship
    entity.HasOne(x => x.LearningModuleFile)
        .WithMany(x => x.Chunks)
        .HasForeignKey(x => x.LearningModuleFileId)
        .OnDelete(DeleteBehavior.Cascade);
});
// ==========================================
// LEARNING SECTION
// ==========================================

modelBuilder.Entity<LearningSection>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.SectionNumber)
        .IsRequired();

    entity.Property(x => x.Title)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.ContentType)
        .IsRequired()
        .HasMaxLength(50);

    entity.Property(x => x.Content)
        .HasMaxLength(10000);

    entity.Property(x => x.MediaUrl)
        .HasMaxLength(1000);

    entity.Property(x => x.DisplayOrder)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired(false);

    entity.HasIndex(x => new
    {
        x.LearningModuleId,
        x.SectionNumber
    })
    .IsUnique();

    entity.HasIndex(x => new
    {
        x.LearningModuleId,
        x.DisplayOrder
    });

    entity.HasOne(x => x.LearningModule)
        .WithMany(x => x.Sections)
        .HasForeignKey(x => x.LearningModuleId)
        .OnDelete(DeleteBehavior.Cascade);
});

        // ==========================================
        // TRAINING PROGRAM DOCUMENT
        // ==========================================

        modelBuilder.Entity<TrainingProgramDocument>(entity =>
        {
            entity.HasKey(x => x.Id);

            

            entity.Property(x => x.DocumentName)
                .IsRequired()
                .HasMaxLength(255);

            entity.Property(x => x.FileUrl)
                .IsRequired()
                .HasMaxLength(1000);

            entity.Property(x => x.PublicId)
                .HasMaxLength(500);

            entity.Property(x => x.UploadedAt)
                .IsRequired();


            entity.HasOne(x => x.TrainingProgram)
                .WithMany(x => x.Documents)
                .HasForeignKey(x => x.TrainingProgramId)
                .OnDelete(DeleteBehavior.Cascade);
        });

modelBuilder.Entity<LearningSectionProgress>(entity =>
{
    entity.ToTable("LearningSectionProgress");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.IsRead)
        .IsRequired();

    entity.Property(x => x.ReadAt)
        .IsRequired(false);

    entity.Property(x => x.LastReadAt)
        .IsRequired();

    entity.HasIndex(x => new
    {
        x.EnrollmentId,
        x.LearningSectionId
    })
    .IsUnique();

    entity.HasOne(x => x.Enrollment)
        .WithMany(x => x.LearningSectionProgresses)
        .HasForeignKey(x => x.EnrollmentId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(x => x.LearningSection)
        .WithMany(x => x.Progresses)
        .HasForeignKey(x => x.LearningSectionId)
        .OnDelete(DeleteBehavior.Cascade);
});

      modelBuilder.Entity<TrainingBatch>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.BatchCode)
        .IsRequired()
        .HasMaxLength(50);

    entity.HasIndex(x => x.BatchCode)
        .IsUnique();

    entity.Property(x => x.Location)
        .HasMaxLength(255);

    entity.Property(x => x.StartDate)
        .IsRequired();

    entity.Property(x => x.EndDate)
        .IsRequired();

    entity.Property(x => x.StartTime)
        .IsRequired(false);

    entity.Property(x => x.EndTime)
        .IsRequired(false);

    
    entity.Property(x => x.Capacity)
        .IsRequired();

    entity.Property(x => x.Status)
        .HasConversion<string>()
        .IsRequired();

    entity.Property(x => x.ScheduleStatus)
        .HasConversion<string>()
        .IsRequired();

    entity.Property(x => x.IncludeWeekends)
        .IsRequired();

    entity.HasOne(x => x.TrainingProgram)
        .WithMany(x => x.Batches)
        .HasForeignKey(x => x.TrainingProgramId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasMany(x => x.TrainerAssignments)
        .WithOne(x => x.TrainingBatch)
        .HasForeignKey(x => x.TrainingBatchId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasMany(x => x.Enrollments)
        .WithOne(x => x.TrainingBatch)
        .HasForeignKey(x => x.TrainingBatchId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasMany(x => x.TrainingSessions)
        .WithOne(x => x.TrainingBatch)
        .HasForeignKey(x => x.TrainingBatchId)
        .OnDelete(DeleteBehavior.Cascade);
});

// ==========================================
// TRAINING SESSION
// ==========================================

modelBuilder.Entity<TrainingSession>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.SessionNumber)
        .IsRequired();

    entity.Property(x => x.SessionDate)
        .IsRequired();

    entity.Property(x => x.StartTime)
        .IsRequired();

    entity.Property(x => x.EndTime)
        .IsRequired();

    entity.Property(x => x.DurationHours)
        .HasPrecision(8, 2)
        .IsRequired();

    entity.Property(x => x.Status)
        .HasConversion<string>()
        .IsRequired();

    entity.HasIndex(x => new
    {
        x.TrainingBatchId,
        x.SessionDate
    });

    entity.HasIndex(x => new
    {
        x.TrainingBatchId,
        x.SessionNumber
    })
    .IsUnique();

    entity.HasOne(x => x.TrainingBatch)
        .WithMany(x => x.TrainingSessions)
        .HasForeignKey(x => x.TrainingBatchId)
        .OnDelete(DeleteBehavior.Cascade);
});

        // ==========================================
        // TRAINER ASSIGNMENT
        // ==========================================

        modelBuilder.Entity<TrainerAssignment>(entity =>
        {
            entity.HasKey(x => x.Id);

            entity.HasIndex(x => x.TrainerProfileId);

            entity.HasIndex(x => x.TrainingBatchId);

            entity.HasIndex(x => x.AssignedByUserId);

            entity.Property(x => x.AssignedAt)
                .IsRequired();

            entity.Property(x => x.IsActive)
                .IsRequired();

            entity.HasOne(x => x.TrainerProfile)
                .WithMany(x => x.Assignments)
                .HasForeignKey(x => x.TrainerProfileId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.TrainingBatch)
                .WithMany(x => x.TrainerAssignments)
                .HasForeignKey(x => x.TrainingBatchId)
                .OnDelete(DeleteBehavior.Restrict);
        });



// ==========================================
// SERVICE
// ==========================================

modelBuilder.Entity<Service>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.ServiceCode)
        .IsRequired()
        .HasMaxLength(50);

    entity.HasIndex(x => x.ServiceCode)
        .IsUnique();

    entity.Property(x => x.Name)
        .IsRequired()
        .HasMaxLength(200);

    entity.Property(x => x.Description)
        .HasMaxLength(2000);

    entity.Property(x => x.Category)
        .IsRequired()
        .HasMaxLength(100);

    entity.Property(x => x.RequiresTraining)
        .IsRequired();

    entity.Property(x => x.IsActive)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired();

    entity.HasMany(x => x.Requirements)
        .WithOne(x => x.Service)
        .HasForeignKey(x => x.ServiceId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasMany(x => x.Requests)
        .WithOne(x => x.Service)
        .HasForeignKey(x => x.ServiceId)
        .OnDelete(DeleteBehavior.Restrict);
});

// ==========================================
// SERVICE REQUIREMENT
// ==========================================

modelBuilder.Entity<ServiceRequirement>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.Name)
        .IsRequired()
        .HasMaxLength(200);

    entity.Property(x => x.Description)
        .HasMaxLength(1000);

    entity.Property(x => x.IsRequired)
        .IsRequired();

    entity.Property(x => x.DisplayOrder)
        .IsRequired();

    entity.HasIndex(x => new
    {
        x.ServiceId,
        x.DisplayOrder
    });

    entity.HasOne(x => x.Service)
        .WithMany(x => x.Requirements)
        .HasForeignKey(x => x.ServiceId)
        .OnDelete(DeleteBehavior.Cascade);
});

// ==========================================
// SERVICE REQUEST
// ==========================================

modelBuilder.Entity<ServiceRequest>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.ApplicantName)
        .IsRequired()
        .HasMaxLength(200);

    entity.Property(x => x.ApplicantEmail)
        .IsRequired()
        .HasMaxLength(320);

    entity.Property(x => x.Remarks)
        .HasMaxLength(2000);

    entity.Property(x => x.Status)
        .HasConversion<string>()
        .IsRequired();

    entity.Property(x => x.ResolutionType)
        .HasConversion<string>()
        .IsRequired(false);

    entity.Property(x => x.AdminRemarks)
        .HasMaxLength(2000);

    entity.Property(x => x.RequestedAt)
        .IsRequired();

    entity.Property(x => x.ReviewedAt)
        .IsRequired(false);

    entity.Property(x => x.UserId)
        .IsRequired(false);

    entity.Property(x => x.ReviewedByUserId)
        .IsRequired(false);

    // Indexes
    entity.HasIndex(x => x.UserId);

    entity.HasIndex(x => x.ServiceId);

    entity.HasIndex(x => x.Status);

    // Service relationship
    entity.HasOne(x => x.Service)
        .WithMany(x => x.Requests)
        .HasForeignKey(x => x.ServiceId)
        .OnDelete(DeleteBehavior.Restrict);

    // Optional applicant/user relationship
    entity.HasOne(x => x.User)
        .WithMany()
        .HasForeignKey(x => x.UserId)
        .IsRequired(false)
        .OnDelete(DeleteBehavior.Restrict);

    // Admin reviewer relationship
    entity.HasOne(x => x.ReviewedByUser)
        .WithMany()
        .HasForeignKey(x => x.ReviewedByUserId)
        .IsRequired(false)
        .OnDelete(DeleteBehavior.Restrict);
});

// ==========================================
// SERVICE CONSULTATION
// ==========================================

modelBuilder.Entity<ServiceConsultation>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.ScheduledAt)
        .IsRequired();

    entity.Property(x => x.EndedAt)
        .IsRequired(false);

    entity.Property(x => x.MeetingLink)
        .IsRequired()
        .HasMaxLength(1000);

    entity.Property(x => x.Notes)
        .HasMaxLength(2000);

    entity.Property(x => x.Status)
        .HasConversion<string>()
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired();

    entity.HasIndex(x => x.ServiceRequestId);

    entity.HasIndex(x => x.ScheduledAt);

    entity.HasOne(x => x.ServiceRequest)
        .WithOne()
        .HasForeignKey<ServiceConsultation>(
            x => x.ServiceRequestId
        )
        .OnDelete(DeleteBehavior.Cascade);
});
        // ==========================================
        // ENROLLMENT
        // ==========================================

        modelBuilder.Entity<Enrollment>(entity =>
        {
            entity.HasKey(x => x.Id);

            // Participant cannot enroll twice
            // in the same training batch.

            entity.HasIndex(x => new
            {
                x.ParticipantProfileId,
                x.TrainingBatchId
            })
            .IsUnique();

            entity.Property(x => x.Status)
                .HasConversion<string>()
                .IsRequired();

            entity.Property(x => x.EnrolledAt)
                .IsRequired();

            entity.Property(x => x.ReviewRemarks)
                .HasMaxLength(1000);

            entity.HasOne(x => x.ParticipantProfile)
                .WithMany(x => x.Enrollments)
                .HasForeignKey(x => x.ParticipantProfileId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.TrainingBatch)
                .WithMany(x => x.Enrollments)
                .HasForeignKey(x => x.TrainingBatchId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasMany(x => x.Documents)
                .WithOne(x => x.Enrollment)
                .HasForeignKey(x => x.EnrollmentId)
                .OnDelete(DeleteBehavior.Cascade);
        });


        // ==========================================
        // ENROLLMENT DOCUMENT
        // ==========================================

        modelBuilder.Entity<EnrollmentDocument>(entity =>
        {
            entity.HasKey(x => x.Id);

            

            entity.Property(x => x.FileName)
                .IsRequired()
                .HasMaxLength(255);

            entity.Property(x => x.FileUrl)
                .IsRequired()
                .HasMaxLength(1000);

            entity.Property(x => x.Status)
                .HasConversion<string>()
                .IsRequired();

            entity.Property(x => x.ReviewRemarks)
                .HasMaxLength(1000);

            entity.Property(x => x.UploadedAt)
                .IsRequired();

            entity.HasOne(x => x.Enrollment)
                .WithMany(x => x.Documents)
                .HasForeignKey(x => x.EnrollmentId)
                .OnDelete(DeleteBehavior.Cascade);
        });


        // ==========================================================
// WRITTEN ASSESSMENT
// ==========================================================

modelBuilder.Entity<WrittenAssessment>(entity =>
{
    entity.ToTable("WrittenAssessments");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Title)
        .IsRequired()
        .HasMaxLength(255);

    entity.Property(x => x.Description)
        .HasMaxLength(2000);

    entity.Property(x => x.PassingPercentage)
        .IsRequired();

    entity.Property(x => x.IsPublished)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired(false);

    entity.HasIndex(x => x.TrainingBatchId);

    entity.HasOne(x => x.TrainingBatch)
        .WithMany()
        .HasForeignKey(x => x.TrainingBatchId)
        .OnDelete(DeleteBehavior.Cascade);
});


// ==========================================================
// ASSESSMENT QUESTION
// ==========================================================

modelBuilder.Entity<AssessmentQuestion>(entity =>
{
    entity.ToTable("AssessmentQuestions");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.QuestionText)
        .IsRequired()
        .HasMaxLength(5000);

    entity.Property(x => x.QuestionNumber)
        .IsRequired();

    entity.Property(x => x.Points)
        .IsRequired();

    entity.Property(x => x.CreatedAt)
        .IsRequired();

    entity.Property(x => x.UpdatedAt)
        .IsRequired(false);

    entity.HasIndex(x => new
    {
        x.WrittenAssessmentId,
        x.QuestionNumber
    })
    .IsUnique();

    entity.HasOne(x => x.WrittenAssessment)
        .WithMany(x => x.Questions)
        .HasForeignKey(x => x.WrittenAssessmentId)
        .OnDelete(DeleteBehavior.Cascade);
});


// ==========================================================
// ASSESSMENT CHOICE
// ==========================================================

modelBuilder.Entity<AssessmentChoice>(entity =>
{
    entity.ToTable("AssessmentChoices");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.ChoiceLabel)
        .IsRequired()
        .HasMaxLength(10);

    entity.Property(x => x.ChoiceText)
        .IsRequired()
        .HasMaxLength(2000);

    entity.Property(x => x.IsCorrect)
        .IsRequired();

    entity.Property(x => x.DisplayOrder)
        .IsRequired();

    entity.HasIndex(x => new
    {
        x.AssessmentQuestionId,
        x.DisplayOrder
    })
    .IsUnique();

    entity.HasOne(x => x.AssessmentQuestion)
        .WithMany(x => x.Choices)
        .HasForeignKey(x => x.AssessmentQuestionId)
        .OnDelete(DeleteBehavior.Cascade);
});


// ==========================================================
// ASSESSMENT ATTEMPT
// ==========================================================

modelBuilder.Entity<AssessmentAttempt>(entity =>
{
    entity.ToTable("AssessmentAttempts");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.AttemptNumber)
        .IsRequired();

    entity.Property(x => x.StartedAt)
        .IsRequired();

    entity.Property(x => x.SubmittedAt)
        .IsRequired(false);

    entity.Property(x => x.Status)
        .IsRequired();

    entity.HasIndex(x => new
    {
        x.WrittenAssessmentId,
        x.EnrollmentId,
        x.AttemptNumber
    })
    .IsUnique();

    entity.HasOne(x => x.WrittenAssessment)
        .WithMany(x => x.Attempts)
        .HasForeignKey(x => x.WrittenAssessmentId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(x => x.Enrollment)
        .WithMany()
        .HasForeignKey(x => x.EnrollmentId)
        .OnDelete(DeleteBehavior.Cascade);
});


// ==========================================================
// ASSESSMENT ANSWER
// ==========================================================

modelBuilder.Entity<AssessmentAnswer>(entity =>
{
    entity.ToTable("AssessmentAnswers");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.EarnedPoints)
        .IsRequired();

    entity.Property(x => x.IsCorrect)
        .IsRequired();

    entity.HasIndex(x => new
    {
        x.AssessmentAttemptId,
        x.AssessmentQuestionId
    })
    .IsUnique();

    entity.HasOne(x => x.AssessmentAttempt)
        .WithMany(x => x.Answers)
        .HasForeignKey(x => x.AssessmentAttemptId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(x => x.AssessmentQuestion)
        .WithMany(x => x.Answers)
        .HasForeignKey(x => x.AssessmentQuestionId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.SelectedChoice)
        .WithMany(x => x.Answers)
        .HasForeignKey(x => x.SelectedChoiceId)
        .OnDelete(DeleteBehavior.Restrict);
});


// ==========================================================
// ASSESSMENT RETAKE REQUEST
// ==========================================================

modelBuilder.Entity<AssessmentRetakeRequest>(entity =>
{
    entity.ToTable("AssessmentRetakeRequests");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.Reason)
        .HasMaxLength(1000)
        .IsRequired(false);

    entity.Property(x => x.Status)
        .HasConversion<int>()
        .IsRequired();

    entity.Property(x => x.RequestedAt)
        .IsRequired();

    entity.Property(x => x.ReviewedAt)
        .IsRequired(false);

    entity.Property(x => x.AdminRemarks)
        .HasMaxLength(1000)
        .IsRequired(false);

    entity.Property(x => x.ReviewedBy)
        .IsRequired(false);

    // ======================================================
    // INDEXES
    // ======================================================

    entity.HasIndex(x => x.ParticipantId);

    entity.HasIndex(x => x.WrittenAssessmentId);

    entity.HasIndex(x => x.PreviousAttemptId);

    entity.HasIndex(x => x.Status);

    // ======================================================
    // PARTICIPANT
    // ======================================================

    entity.HasOne(x => x.ParticipantProfile)
        .WithMany()
        .HasForeignKey(x => x.ParticipantId)
        .OnDelete(DeleteBehavior.Restrict);

    // ======================================================
    // WRITTEN ASSESSMENT
    // ======================================================

    entity.HasOne(x => x.WrittenAssessment)
        .WithMany()
        .HasForeignKey(x => x.WrittenAssessmentId)
        .OnDelete(DeleteBehavior.Restrict);

    // ======================================================
    // PREVIOUS ATTEMPT
    // ======================================================

    entity.HasOne(x => x.PreviousAttempt)
        .WithMany()
        .HasForeignKey(x => x.PreviousAttemptId)
        .OnDelete(DeleteBehavior.Restrict);
});


// ==========================================================
// ASSESSMENT RESULT
// ==========================================================

modelBuilder.Entity<AssessmentResult>(entity =>
{
    entity.ToTable("AssessmentResults");

    entity.HasKey(x => x.Id);

    entity.Property(x => x.TotalQuestions)
        .IsRequired();

    entity.Property(x => x.CorrectAnswers)
        .IsRequired();

    entity.Property(x => x.TotalPoints)
        .IsRequired();

    entity.Property(x => x.EarnedPoints)
        .IsRequired();

    entity.Property(x => x.Percentage)
        .HasPrecision(5, 2)
        .IsRequired();

    entity.Property(x => x.IsPassed)
        .IsRequired();

    entity.Property(x => x.EvaluatedAt)
        .IsRequired();

    entity.HasIndex(x => x.AssessmentAttemptId)
        .IsUnique();

    entity.HasOne(x => x.AssessmentAttempt)
        .WithOne(x => x.Result)
        .HasForeignKey<AssessmentResult>(
            x => x.AssessmentAttemptId
        )
        .OnDelete(DeleteBehavior.Cascade);
});
 // ==========================================
// ATTENDANCE SESSION
// ==========================================

modelBuilder.Entity<AttendanceSession>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.Status)
        .HasConversion<string>()
        .IsRequired();

    entity.Property(x => x.ManualAttendanceStatus)
        .HasConversion<string>()
        .IsRequired();

    entity.Property(x => x.OpenedAt)
        .IsRequired();

    entity.Property(x => x.ClosedAt)
        .IsRequired(false);

    entity.Property(x => x.OpenedByUserId)
        .IsRequired();

    entity.HasIndex(x => x.TrainingBatchId);

    entity.HasIndex(x => x.Status);

    entity.HasOne(x => x.TrainingBatch)
        .WithMany(x => x.AttendanceSessions)
        .HasForeignKey(x => x.TrainingBatchId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.TrainingSession)
    .WithMany(x => x.AttendanceSessions)
    .HasForeignKey(x => x.TrainingSessionId)
    .OnDelete(DeleteBehavior.Restrict);


    entity.HasMany(x => x.Records)
        .WithOne(x => x.AttendanceSession)
        .HasForeignKey(x => x.AttendanceSessionId)
        .OnDelete(DeleteBehavior.Cascade);
    

});


// ==========================================
// ATTENDANCE RECORD
// ==========================================

modelBuilder.Entity<AttendanceRecord>(entity =>
{
    entity.HasKey(x => x.Id);

    entity.Property(x => x.Status)
        .HasConversion<string>()
        .IsRequired();

    entity.Property(x => x.Method)
        .HasMaxLength(50);

    entity.Property(x => x.AttendanceDate)
        .IsRequired();

    entity.Property(x => x.TimeIn)
        .IsRequired(false);

    entity.Property(x => x.TimeOut)
        .IsRequired(false);

    entity.HasIndex(x => x.AttendanceSessionId);

    entity.HasIndex(x => x.EnrollmentId);

    // ==========================================
    // ONE ATTENDANCE PER ENROLLMENT PER DAY
    // ==========================================
    //
    // QR + Manual use the same record.
    //
    // Example:
    //
    // Enrollment A + Sept 4 = allowed
    // Enrollment A + Sept 4 = duplicate
    // Enrollment A + Sept 5 = allowed
    //
    entity.HasIndex(x => new
{
    x.EnrollmentId,
    x.AttendanceSessionId
})
.IsUnique();
    entity.HasOne(x => x.AttendanceSession)
        .WithMany(x => x.Records)
        .HasForeignKey(x => x.AttendanceSessionId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(x => x.Enrollment)
        .WithMany()
        .HasForeignKey(x => x.EnrollmentId)
        .OnDelete(DeleteBehavior.Restrict);
});
    }

    
    

    
}